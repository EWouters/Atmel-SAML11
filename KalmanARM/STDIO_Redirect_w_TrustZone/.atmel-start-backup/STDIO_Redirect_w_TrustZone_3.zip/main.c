//#include <atmel_start.h>
//#include "stdio_start.h"
//
//int main(void)
//{
	///* Initializes MCU, drivers and middleware */
	//atmel_start_init();
	//stdio_redirect_init();
	////STDIO_REDIRECT_0_example();
//
	///* Replace with your application code */
	//while (1) {
		//printf("hi\n");
	//}
//}

#include <atmel_start.h>

#include "stdio_start.h"



struct io_descriptor *io;





void TARGET_IO_example2(void)

{

	usart_sync_get_io_descriptor(&TARGET_IO, &io);

	usart_sync_enable(&TARGET_IO);

	

}



int main(void)

{

	/* Initializes MCU, drivers and middleware */

	atmel_start_init();

	TARGET_IO_example2();

	

	io_write(io, (uint8_t *)"Hello World!", 12);

	printf("\r\nHello ATMEL World!\r\n");
	printf("\r\nHello ATMEL World!\r\n");

	

	/* Replace with your application code */

	while (1) {

	}

}